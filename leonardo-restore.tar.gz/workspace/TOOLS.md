# TOOLS.md - Local Notes

## Discord Channel Ownership

| Channel | ID | Owner | Non-owners |
|---------|-----|-------|------------|
| `#launchpad-general` | 1470919420791619758 | **Leonardo** 🔵 | @mention only |
| `#launchpad-private` | 1470919437975814226 | **Leonardo** 🔵 | @mention only |
| `#command-center` | 1468164160398557216 | **Molty** 🦎 | @mention only |
| `#squad-updates` | 1468164181155909743 | **Molty** 🦎 | Read-only |
| `#brinc-general` | 1468164121420628081 | **Raphael** 🔴 | @mention only |
| `#brinc-private` | 1468164139674238976 | **Raphael** 🔴 | @mention only |

## Guillermo's Discord
**User ID:** `779143499655151646`

## Agent Webhooks
| Agent | URL | Token |
|-------|-----|-------|
| Molty | https://ggvmolt.up.railway.app/hooks/agent | HSYgqkBANp8ChScOEs2bo09fQ2hnFw0lqW5tZjOPmvkrCffmcuce6aVyF7p1vfTU |
| Raphael | https://ggv-raphael.up.railway.app/hooks/agent | HSYgqkBANp8ChScOEs2bo09fQ2hnFw0lqW5tZjOPmvkrCffmcuce6aVyF7p1vfTU |

## Railway
- **Project:** leonardo
- **Project ID:** 56793cec-6283-4af0-ae1f-ac10ec622e58
- **URL:** https://leonardo-production.up.railway.app
- **Volume:** /data

## Notion
- **Mission Control:** https://www.notion.so/Leonardo-The-Launchpad-30439dd69afd81cd96ffe779dd9ab011
- **Mission Control Page ID:** 30439dd6-9afd-81cd-96ff-e779dd9ab011
- **Launchpad Tasks DB:** 30439dd6-9afd-81d1-b940-d2a859d5e84b
- **Task Statuses:** Backlog → Next → Doing → Blocked → Review → Done
- **Priorities:** P1/P2/P3/P4
- **Projects:** Cerebro, Proposal Studio, Infrastructure

## Cerebro
- **URL:** meetcerebro.com
- **Notion Page:** 2fa39dd6-9afd-81e7-b73b-c440d9797eef

## Proposal Studio
- **Frontend:** https://wonderful-harmony-production.up.railway.app
- **Backend:** https://considerate-light-production.up.railway.app
- **Railway Project ID:** 001331eb-af71-4ab5-9c3a-8e6589dbc409

---

*Add whatever helps you do your job. This is your cheat sheet.*
